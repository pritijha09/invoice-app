import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-builder',
  template: `
<app-side-nav></app-side-nav>
  `,
  styles: []
})
export class InvoiceBuilderComponent implements OnInit {

  constructor() {
    alert("hii")
  }

  ngOnInit() {
  }

}
